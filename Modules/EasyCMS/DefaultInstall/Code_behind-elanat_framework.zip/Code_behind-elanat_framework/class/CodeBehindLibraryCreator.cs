using System.Text.RegularExpressions;
using System.Reflection;
using CodeBehind;
using CodeBehind.HtmlData;

namespace SetCodeBehind
{
    class CodeBehindLibraryCreator
    {
        private List<string> ErrorList = new List<string>();
        private bool RewriteAspxFileToDirectory;
        private bool AccessAspxFileAfterRewrite;
        private bool IgnoreDefaultAfterRewrite;
        private bool StartTrimInAspxFile;
        private bool EndTrimInAspxFile;
        private bool SetBreakForLayoutPage;
        private bool InnerTrimInAspxFile;
        private string CaseCodeTemplateValue = "";
        private string SectionTemplateValue = "";
        private string CaseCodeTemplateValueForFullPath = "";
        private string MethodCodeTemplateValue = "";
        private string GlobalTemplate = "";

        public string GetCodeBehindViews()
        {
            if (!Directory.Exists("code_behind"))
                Directory.CreateDirectory("code_behind");

            string AllAspxFiles = "";

            string FilePath = "code_behind/views_class.cs.tmp";
            if (!File.Exists(FilePath))
            {
                AllAspxFiles = CreateAllAspxFiles();

                string[] lines = AllAspxFiles.Split(Environment.NewLine);

                // Create views_class.cs File
                var file = File.CreateText(FilePath);

                foreach (string line in lines)
                {
                    file.WriteLine(line);
                }

                file.Dispose();
                file.Close();
            }
            else
            {
                using (StreamReader reader = new StreamReader(FilePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        AllAspxFiles += line + Environment.NewLine;
                    }
                }
            }

            return AllAspxFiles;
        }

        public string GetLastSuccessCompiledViewClass()
        {
            string AllAspxFiles = "";

            if (!Directory.Exists("code_behind"))
            {
                Directory.CreateDirectory("code_behind");
                return AllAspxFiles;
            }

            const string FilePath = "code_behind/views_class_last_success_compiled.cs.tmp";
            if (File.Exists(FilePath))
            {
                using (StreamReader reader = new StreamReader(FilePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        AllAspxFiles += line + Environment.NewLine;
                    }
                }
            }

            return AllAspxFiles;
        }

        public string CreateAllAspxFiles()
        {
            string CodeBehindViews = "";
            CodeBehindViews += "using " + Assembly.GetEntryAssembly().GetName().Name + ";" + Environment.NewLine;
            CodeBehindViews += "using CodeBehind;" + Environment.NewLine;
            CodeBehindViews += "using System;" + Environment.NewLine;
            CodeBehindViews += "using System.Runtime;" + Environment.NewLine;
            CodeBehindViews += "using Microsoft.AspNetCore.Http;" + Environment.NewLine;
            CodeBehindViews += ImportNamespaceList();
            CodeBehindViews += Environment.NewLine;
            CodeBehindViews += "namespace CodeBehindViews" + Environment.NewLine;
            CodeBehindViews += "{" + Environment.NewLine;
            CodeBehindViews += "    public class CodeBehindViewsList" + Environment.NewLine;
            CodeBehindViews += "    {" + Environment.NewLine;
            CodeBehindViews += "        private CodeBehind.HtmlData.NameValueCollection ViewData = new CodeBehind.HtmlData.NameValueCollection();" + Environment.NewLine;
            CodeBehindViews += "        private string RequestPath { get; set; } = \"\";" + Environment.NewLine;
            CodeBehindViews += "        private string CallerViewPath { get; set; } = \"\";" + Environment.NewLine;
            CodeBehindViews += "        private string CallerViewDirectoryPath { get; set; } = \"\";" + Environment.NewLine;
            CodeBehindViews += "        private bool FoundPage { get; set; } = true;" + Environment.NewLine + Environment.NewLine;

            CodeBehindOptions options = new CodeBehindOptions();
            RewriteAspxFileToDirectory = options.RewriteAspxFileToDirectory;
            AccessAspxFileAfterRewrite = options.AccessAspxFileAfterRewrite;
            IgnoreDefaultAfterRewrite = options.IgnoreDefaultAfterRewrite;
            StartTrimInAspxFile = options.StartTrimInAspxFile;
            EndTrimInAspxFile = options.EndTrimInAspxFile;
            SetBreakForLayoutPage = options.SetBreakForLayoutPage;
            InnerTrimInAspxFile = options.InnerTrimInAspxFile;


            // Create wwwroot Directory And Set Default Pages
            if (options.ViewPath == "wwwroot")
                if (!Directory.Exists("wwwroot"))
                {
                    Directory.CreateDirectory("wwwroot");

                    string FilePath = "wwwroot/layout.aspx";
                    var file1 = File.CreateText(FilePath);

                    file1.WriteLine("@page");
                    file1.WriteLine("@islayout");
                    file1.WriteLine("@{");
                    file1.WriteLine("  string WelcomeText = \"Welcome to the CodeBehind Framework!\";");
                    file1.WriteLine("}");
                    file1.WriteLine("<!DOCTYPE html>");
                    file1.WriteLine("<html>");
                    file1.WriteLine("<head>");
                    file1.WriteLine("  <title>CodeBehind Framework - @ViewData.GetValue(\"title\")</title>");
                    file1.WriteLine("  <meta charset=\"utf-8\" />");
                    file1.WriteLine("  <style>");
                    file1.WriteLine("  body");
                    file1.WriteLine("  {");
                    file1.WriteLine("      font-family: Arial, sans-serif;");
                    file1.WriteLine("      margin: 0;");
                    file1.WriteLine("      padding: 0;");
                    file1.WriteLine("      line-height: 32px;");
                    file1.WriteLine("  }");
                    file1.WriteLine();
                    file1.WriteLine("  header");
                    file1.WriteLine("  {");
                    file1.WriteLine("      background-color: #f2f2f2;");
                    file1.WriteLine("      text-align: center;");
                    file1.WriteLine("      padding: 20px 0;");
                    file1.WriteLine("  }");
                    file1.WriteLine();
                    file1.WriteLine("  nav");
                    file1.WriteLine("  {");
                    file1.WriteLine("      background-color: #90dbff;");
                    file1.WriteLine("      color: #fff;");
                    file1.WriteLine("      text-align: center;");
                    file1.WriteLine("      padding: 10px 0;");
                    file1.WriteLine("  }");
                    file1.WriteLine();
                    file1.WriteLine("  nav ul");
                    file1.WriteLine("  {");
                    file1.WriteLine("      list-style-type: none;");
                    file1.WriteLine("      padding: 0;");
                    file1.WriteLine("  }");
                    file1.WriteLine();
                    file1.WriteLine("  nav ul li");
                    file1.WriteLine("  {");
                    file1.WriteLine("      display: inline;");
                    file1.WriteLine("      margin: 0 10px;");
                    file1.WriteLine("  }");
                    file1.WriteLine();
                    file1.WriteLine("  footer");
                    file1.WriteLine("  {");
                    file1.WriteLine("      background-color: #333;");
                    file1.WriteLine("      color: #fff;");
                    file1.WriteLine("      text-align: center;");
                    file1.WriteLine("      padding: 10px 0;");
                    file1.WriteLine("  }");
                    file1.WriteLine("  </style>");
                    file1.WriteLine("</head>");
                    file1.WriteLine("<body>");
                    file1.WriteLine();
                    file1.WriteLine("  @LoadPage(\"/header.aspx\")");
                    file1.WriteLine();
                    file1.WriteLine("  <nav>");
                    file1.WriteLine("      <ul>");
                    file1.WriteLine("          <li><a href=\"/\">Home</a></li>");
                    file1.WriteLine("          <li><a href=\"#\">About</a></li>");
                    file1.WriteLine("          <li><a href=\"#\">Contact</a></li>");
                    file1.WriteLine("      </ul>");
                    file1.WriteLine("  </nav>");
                    file1.WriteLine();
                    file1.WriteLine("  <h2>CodeBehind Framework - @ViewData.GetValue(\"title\")</h2>");
                    file1.WriteLine("  <p>Text value is: @WelcomeText</p>");
                    file1.WriteLine();
                    file1.WriteLine("  @PageReturnValue");
                    file1.WriteLine();
                    file1.WriteLine("  @LoadPage(\"/footer.aspx\")");
                    file1.WriteLine();
                    file1.WriteLine("</body>");
                    file1.WriteLine("</html>");

                    file1.Dispose();
                    file1.Close();


                    FilePath = "wwwroot/Default.aspx";
                    var file2 = File.CreateText(FilePath);

                    file2.WriteLine("@page");
                    file2.WriteLine("@layout \"/layout.aspx\"");
                    file2.WriteLine("@{");
                    file2.WriteLine("  ViewData.Add(\"title\",\"Main page\");");
                    file2.WriteLine("}");
                    file2.WriteLine("  <main>");
                    file2.WriteLine("      <p>CodeBehind library is a modern back-end framework and is an alternative to ASP.NET Core. This library is a programming model based on the MVC structure, which provides the possibility of creating dynamic aspx files in .NET Core and has high serverside independence. CodeBehind framework supports standard syntax and Razor syntax. This framework guarantees the separation of server-side codes from the design part (html) and there is no need to write server-side codes in the view.</p>");
                    file2.WriteLine("      <p>Code Behind framework inherits every advantage of ASP.NET Core and gives it more simplicity, power and flexibility.</p>");
                    file2.WriteLine("      <p><b>CodeBehind framework is an alternative to ASP.NET Core.</b></p>");
                    file2.WriteLine("      <h3>Why use CodeBehind?</h3>");
                    file2.WriteLine("      <ul>");
                    file2.WriteLine("          <li><b>Fast:</b> The CodeBehind framework is faster than the default structure of cshtml pages in ASP.NET Core.</li>");
                    file2.WriteLine("          <li><b>Simple:</b> Developing with CodeBehind is very simple. You can use mvc pattern or model-view or controller-view or only view.</li>");
                    file2.WriteLine("          <li><b>Modular:</b> It is modular. Just copy the new project files, including dll and aspx, into the current active project.</li>");
                    file2.WriteLine("          <li><b>Get output:</b> You can call the output of the aspx page in another aspx page and modify its output.</li>");
                    file2.WriteLine("          <li><b>Under .NET Core:</b> Your project will still be under ASP.NET Core and you will benefit from all the benefits of .NET Core.</li>");
                    file2.WriteLine("          <li><b>Code-Behind:</b> Code-Behind pattern will be fully respected.</li>");
                    file2.WriteLine("          <li><b>Modern:</b> CodeBehind is a modern framework with revolutionary ideas.</li>");
                    file2.WriteLine("          <li><b>Understandable:</b> View is preferable to controller and there is no need to set controllers in route.</li>");
                    file2.WriteLine("      </ul>");
                    file2.WriteLine("      <p><b>CodeBehind is .NET Diamond!</b></p>");
                    file2.WriteLine("      <p>In every scenario, CodeBehind performs better than the default structure in ASP.NET Core.</p>");
                    file2.WriteLine("  </main>");

                    file2.Dispose();
                    file2.Close();


                    FilePath = "wwwroot/header.aspx";
                    var file3 = File.CreateText(FilePath);

                    file3.WriteLine("@page");
                    file3.WriteLine("@break");
                    file3.WriteLine("  <header>");
                    file3.WriteLine("      <h1>Company name</h1>");
                    file3.WriteLine("  </header>");

                    file3.Dispose();
                    file3.Close();


                    FilePath = "wwwroot/footer.aspx";
                    var file4 = File.CreateText(FilePath);

                    file4.WriteLine("@page");
                    file4.WriteLine("@break");
                    file4.WriteLine("  <footer>");
                    file4.WriteLine("      <p>&copy; @DateTime.Now.ToString(\"yyyy\") Company name - Built with <a href=\"https://elanat.net/page_content/code_behind\" title=\"CodeBehind Framework\">CodeBehind Framework</a></p>");
                    file4.WriteLine("  </footer>");

                    file4.Dispose();
                    file4.Close();


                    FilePath = "wwwroot/error.aspx";
                    var file5 = File.CreateText(FilePath);

                    file5.WriteLine("@page");
                    file5.WriteLine("@layout \"/layout.aspx\"");
                    file5.WriteLine("@section");
                    file5.WriteLine("@{");
                    file5.WriteLine("  ViewData.Add(\"title\",\"Error page\");");
                    file5.WriteLine();
                    file5.WriteLine("  int ErrorValue = 0;");
                    file5.WriteLine("  if (Section.GetValue(0).IsNumber())");
                    file5.WriteLine("    ErrorValue = Section.GetValue(0).ToNumber();");
                    file5.WriteLine("}");
                    file5.WriteLine("  <main>");
                    file5.WriteLine("      <div>");
                    file5.WriteLine("      @if (ErrorValue == 400)");
                    file5.WriteLine("      {");
                    file5.WriteLine("        <h1>Error 400 Bad request</h1>");
                    file5.WriteLine("        <h3>The path you requested is incorrect or the server cannot respond to this request.</h3>");
                    file5.WriteLine("      }");
                    file5.WriteLine("      else if (ErrorValue == 401)");
                    file5.WriteLine("      {");
                    file5.WriteLine("        <h1>Error 401 Authorization required</h1>");
                    file5.WriteLine("        <h3>The path you requested requires validation. Either you don't have access to the path or you need to log in.</h3>");
                    file5.WriteLine("      }");
                    file5.WriteLine("      else if (ErrorValue == 403)");
                    file5.WriteLine("      {");
                    file5.WriteLine("        <h1>Error 403 Forbidden</h1>");
                    file5.WriteLine("        <h3>The path you requested cannot be accessed.</h3>");
                    file5.WriteLine("      }");
                    file5.WriteLine("      else if (ErrorValue == 404)");
                    file5.WriteLine("      {");
                    file5.WriteLine("        <h1>Error 404 Page not found</h1>");
                    file5.WriteLine("        <h3>No page was found in the path you requested.</h3>");
                    file5.WriteLine("      }");
                    file5.WriteLine("      else if (ErrorValue == 500)");
                    file5.WriteLine("      {");
                    file5.WriteLine("        <h1>Error 500 Internal server error</h1>");
                    file5.WriteLine("        <h3>The server encountered an unexpected problem, so the problem prevented us from responding to your request.</h3>");
                    file5.WriteLine("      }");
                    file5.WriteLine("      else");
                    file5.WriteLine("      {");
                    file5.WriteLine("        <h1>Error! Status Code: @ErrorValue</h1>");
                    file5.WriteLine("        <h3>A problem has occurred.</h3>");
                    file5.WriteLine("      }");
                    file5.WriteLine("      </div>");
                    file5.WriteLine("  </main>");

                    file5.Dispose();
                    file5.Close();
                }

            // Fill Global Template
            FillGlobalTemplate();


            // Move View From Wwwroot
            if ((options.ViewPath != "wwwroot") && options.MoveViewFromWwwroot)
            {
                MoveViewFromWwwroot(options.ViewPath, "aspx");
                MoveViewFromWwwroot(options.ViewPath, "astx");

                if (options.ConvertCsHtmlToAspx)
                    MoveViewFromWwwroot(options.ViewPath, "cshtml");
            }


            DirectoryInfo RootDir = new DirectoryInfo(options.ViewPath);
            string RootDirectoryPath = RootDir.FullName;
            int i = 1;
            foreach (FileInfo file in RootDir.GetFiles("*.aspx", SearchOption.AllDirectories))
            {
                AspxTextAndCodeCombination(file.FullName, RootDirectoryPath, i);
                i++;
            }

            if (options.ConvertCsHtmlToAspx)
            foreach (FileInfo file in RootDir.GetFiles("*.cshtml", SearchOption.AllDirectories))
                {
                    AspxTextAndCodeCombination(file.FullName, RootDirectoryPath, i);
                    i++;
                }

            CodeBehindViews += "        // It Works Based On Rewriting The Option File" + Environment.NewLine;
            CodeBehindViews += "        public string SetPageLoadByPath(string path, HttpContext context)" + Environment.NewLine;
            CodeBehindViews += "        {" + Environment.NewLine;
            CodeBehindViews += "            RequestPath = path;" + Environment.NewLine;
            CodeBehindViews += "            FoundPage = true;" + Environment.NewLine + Environment.NewLine;
            CodeBehindViews += (!string.IsNullOrEmpty(SectionTemplateValue))? SectionTemplateValue + Environment.NewLine : "";
            CodeBehindViews += "            switch (path)" + Environment.NewLine;
            CodeBehindViews += "            {" + Environment.NewLine;
            CodeBehindViews += CaseCodeTemplateValue + Environment.NewLine;
            CodeBehindViews += "            }" + Environment.NewLine + Environment.NewLine;
            CodeBehindViews += "            FoundPage = false;" + Environment.NewLine;
            CodeBehindViews += "            return \"\";" + Environment.NewLine;
            CodeBehindViews += "        }" + Environment.NewLine + Environment.NewLine;

            CodeBehindViews += "        // Load All Page By Full Path, This Method Load Break Page And Does Not Apply Rewrite" + Environment.NewLine;
            CodeBehindViews += "        public string SetPageLoadByFullPath(string path, HttpContext context, string PageReturnValue = \"\")" + Environment.NewLine;
            CodeBehindViews += "        {" + Environment.NewLine;
            CodeBehindViews += "            RequestPath = path;" + Environment.NewLine;
            CodeBehindViews += "            FoundPage = true;" + Environment.NewLine + Environment.NewLine;
            CodeBehindViews += "            switch (path)" + Environment.NewLine;
            CodeBehindViews += "            {" + Environment.NewLine;
            CodeBehindViews += CaseCodeTemplateValueForFullPath + Environment.NewLine;
            CodeBehindViews += "            }" + Environment.NewLine + Environment.NewLine;
            CodeBehindViews += "            FoundPage = false;" + Environment.NewLine;
            CodeBehindViews += "            return \"\";" + Environment.NewLine;
            CodeBehindViews += "        }" + Environment.NewLine + Environment.NewLine;

            // Add Load Page Method
            CodeBehindViews += "        private string LoadPage(string path, HttpContext context)" + Environment.NewLine;
            CodeBehindViews += "        {" + Environment.NewLine;
            CodeBehindViews += "            return SetPageLoadByFullPath(path, context);" + Environment.NewLine;
            CodeBehindViews += "        }" + Environment.NewLine + Environment.NewLine;

            CodeBehindViews += "        // Overload" + Environment.NewLine;
            CodeBehindViews += "        private string LoadPage(string path)" + Environment.NewLine;
            CodeBehindViews += "        {" + Environment.NewLine;
            CodeBehindViews += "            return SetPageLoadByFullPath(path, null);" + Environment.NewLine;
            CodeBehindViews += "        }" + Environment.NewLine + Environment.NewLine;

            CodeBehindViews += "        public bool PageHasFound()" + Environment.NewLine;
            CodeBehindViews += "        {" + Environment.NewLine;
            CodeBehindViews += "            return FoundPage;" + Environment.NewLine;
            CodeBehindViews += "        }" + Environment.NewLine + Environment.NewLine;

            CodeBehindViews += "        private void Download(HttpContext context, string FilePath)" + Environment.NewLine;
            CodeBehindViews += "        {" + Environment.NewLine;
            CodeBehindViews += "            long FileSize = new FileInfo(FilePath).Length;" + Environment.NewLine;
            CodeBehindViews += "            var response = context.Response;" + Environment.NewLine;
            CodeBehindViews += "            response.Headers.Add(\"Content-Length\", FileSize.ToString());" + Environment.NewLine;
            CodeBehindViews += "            response.ContentType = \"application/octet-stream\";" + Environment.NewLine;
            CodeBehindViews += "            response.Headers.Add(\"Content-Disposition\", $\"attachment; filename=\\\"{System.IO.Path.GetFileName(FilePath)}\\\"\");" + Environment.NewLine;
            CodeBehindViews += "            using (var stream = new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))" + Environment.NewLine;
            CodeBehindViews += "            {" + Environment.NewLine;
            CodeBehindViews += "                var bufferSize = 64 * 1024; // 64KB" + Environment.NewLine;
            CodeBehindViews += "                var buffer = new byte[bufferSize];" + Environment.NewLine;
            CodeBehindViews += "                int bytesRead;" + Environment.NewLine;
            CodeBehindViews += "                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)" + Environment.NewLine;
            CodeBehindViews += "                {" + Environment.NewLine;
            CodeBehindViews += "                    try" + Environment.NewLine;
            CodeBehindViews += "                    {" + Environment.NewLine;
            CodeBehindViews += "                        response.Body.WriteAsync(buffer, 0, bytesRead);" + Environment.NewLine;
            CodeBehindViews += "                        response.Body.FlushAsync();" + Environment.NewLine;
            CodeBehindViews += "                    }" + Environment.NewLine;
            CodeBehindViews += "                    catch" + Environment.NewLine;
            CodeBehindViews += "                    {" + Environment.NewLine;
            CodeBehindViews += "                        break;" + Environment.NewLine;
            CodeBehindViews += "                    }" + Environment.NewLine;
            CodeBehindViews += "                }" + Environment.NewLine;
            CodeBehindViews += "            }" + Environment.NewLine;
            CodeBehindViews += "        }" + Environment.NewLine;

            CodeBehindViews += MethodCodeTemplateValue;

            CodeBehindViews += "    }" + Environment.NewLine;
            CodeBehindViews += "}" + Environment.NewLine + Environment.NewLine;

            CodeBehindViews += "namespace " + Assembly.GetEntryAssembly().GetName().Name + Environment.NewLine;
            CodeBehindViews += "{" + Environment.NewLine;
            CodeBehindViews += "    public partial class CodeBehindEmptyClass" + Environment.NewLine;
            CodeBehindViews += "    {" + Environment.NewLine;
            CodeBehindViews += "    }" + Environment.NewLine;
            CodeBehindViews += "}";


            SaveError(ErrorList);
            return CodeBehindViews;
        }

        public void AspxTextAndCodeCombination(string FilePath, string RootDirectoryPath, int MethodIndexer)
        {
            var Lines = File.OpenText(FilePath);
            string AspxText = "";
            var TmpLine = "";
            while ((TmpLine = Lines.ReadLine()) != null)
            {
                AspxText += TmpLine + '\n';
            }

            AspxText = AspxText.GetTextBeforeLastValue('\n'.ToString());

            Lines.Close();

            // Fetch Page
            if (AspxText.Contains("<%@"))
                AspxTextAndCodeCombinationStandard(AspxText, FilePath, RootDirectoryPath, MethodIndexer);
            else
                AspxTextAndCodeCombinationRazor(AspxText, FilePath, RootDirectoryPath, MethodIndexer);
        }

        public void SetMethod(string AspxFilePath, string Controller, string ControllerConstructor, string Model, string ModelConstructor, bool ModelUseAbstract, bool ControllerIsSet, string Layout, bool IsLayout, bool IsBreak, bool UseSection, int MethodIndexer, string TextToCodeCombination)
        {
            if (AspxFilePath.EndsWith(".cshtml"))
                AspxFilePath = AspxFilePath.GetTextBeforeLastValue(".cshtml") + ".aspx";


            string FilePathToMethodName = AspxFilePath.ToMethodNameClean();
            bool PageIsOnlyView = !ControllerIsSet;

            if (!IsBreak)
                if (IsLayout && SetBreakForLayoutPage)
                    IsBreak = true;

            string AspxFilePathUrl = AspxFilePath.Replace("\\", "/");

            if (!IsBreak)
            {
                string ReturnMethodValue = FilePathToMethodName + "_" + Controller.Replace('.', '_') + "_PageLoad" + MethodIndexer + "(context" + (IsLayout ? ", \"\"" : "") + ")";


                if (!RewriteAspxFileToDirectory || (RewriteAspxFileToDirectory && AccessAspxFileAfterRewrite && !(IgnoreDefaultAfterRewrite && (AspxFilePath.GetTextAfterLastValue('\\'.ToString()) == "Default.aspx"))))
                {
                    CaseCodeTemplateValue += "                case \"" + AspxFilePathUrl + "\": return " + ReturnMethodValue + ";" + Environment.NewLine;

                    if (UseSection)
                    {
                        SectionTemplateValue += "            if (path.StartsWith(\"" + AspxFilePathUrl + "/\")" + ((AspxFilePath.GetTextAfterLastValue('\\'.ToString()) == "Default.aspx")? " || path.StartsWith(\"" + AspxFilePathUrl.GetTextBeforeLastValue("Default.aspx") + "\")" : "") + ")" + Environment.NewLine;
                        SectionTemplateValue += "                return " + ReturnMethodValue + ";" + Environment.NewLine;
                    }
                }

                if (RewriteAspxFileToDirectory)
                    if (IgnoreDefaultAfterRewrite && (AspxFilePath.GetTextAfterLastValue('\\'.ToString()) == "Default.aspx"))
                    {
                        CaseCodeTemplateValue += "                case \"" + AspxFilePathUrl + "\": return " + ReturnMethodValue + ";" + Environment.NewLine;

                        if (UseSection)
                        {
                            SectionTemplateValue += "            if (path.StartsWith(\"" + AspxFilePathUrl.GetTextBeforeLastValue("Default.aspx") + "\") || path.StartsWith(\"" + AspxFilePathUrl + "/\"))" + Environment.NewLine;
                            SectionTemplateValue += "                return " + ReturnMethodValue + ";" + Environment.NewLine;
                        }
                    }
                    else
                    {
                        CaseCodeTemplateValue += "                case \"" + AspxFilePathUrl.GetTextBeforeLastValue(".aspx") + "/Default.aspx" + "\": return " + ReturnMethodValue + ";" + Environment.NewLine;

                        if (UseSection)
                        {
                            SectionTemplateValue += "            if (path.StartsWith(\"" + AspxFilePathUrl.GetTextBeforeLastValue(".aspx") + "/\"))" + Environment.NewLine;
                            SectionTemplateValue += "                return " + ReturnMethodValue + ";" + Environment.NewLine;
                        }
                    }
            }

            CaseCodeTemplateValueForFullPath += "                case \"" + AspxFilePathUrl + "\": return " + FilePathToMethodName + "_" + Controller.Replace('.', '_') + "_PageLoad" + MethodIndexer + "(context" + (IsLayout? ", PageReturnValue" : "") + ");" + Environment.NewLine;

            string CallerViewDirectoryPath = AspxFilePathUrl.GetTextBeforeLastValue("/");
            if (string.IsNullOrEmpty(CallerViewDirectoryPath))
                CallerViewDirectoryPath = "/";

            string TmpMethodCodeTemplateValue = Environment.NewLine;
            TmpMethodCodeTemplateValue += "        // View Path: " + AspxFilePathUrl + Environment.NewLine;
            TmpMethodCodeTemplateValue += "        protected string " + FilePathToMethodName + "_" + Controller.Replace('.', '_') + "_PageLoad" + MethodIndexer + "(HttpContext context" + (IsLayout? ", string PageReturnValue" : "") + ")" + Environment.NewLine;
            TmpMethodCodeTemplateValue += "        {" + Environment.NewLine;
            TmpMethodCodeTemplateValue += "            string PreviousRequestPath = RequestPath;" + Environment.NewLine;
            TmpMethodCodeTemplateValue += "            string PreviousCallerViewPath = CallerViewPath;" + Environment.NewLine;
            TmpMethodCodeTemplateValue += "            string PreviousCallerViewDirectoryPath = CallerViewDirectoryPath;" + Environment.NewLine;
            TmpMethodCodeTemplateValue += "            CallerViewPath = \"" + AspxFilePathUrl + "\";" + Environment.NewLine;
            TmpMethodCodeTemplateValue += "            CallerViewDirectoryPath = \"" + CallerViewDirectoryPath + "\";" + Environment.NewLine + Environment.NewLine;

            if (UseSection)
                TmpMethodCodeTemplateValue += "            ValueCollectionLock Section = new ValueCollectionLock(\"" + AspxFilePathUrl + "\", RequestPath, " + (RewriteAspxFileToDirectory? "true" : "false" ) + ", " + (IgnoreDefaultAfterRewrite ? "true" : "false") + ");" + Environment.NewLine + Environment.NewLine;

            if (!PageIsOnlyView)
            {
                TmpMethodCodeTemplateValue += "            " + Controller + " controller = new " + Controller + "();" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            controller.CallerViewPath = CallerViewPath;" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            controller.CallerViewDirectoryPath = CallerViewDirectoryPath;" + Environment.NewLine;

                if (UseSection)
                    TmpMethodCodeTemplateValue += "            controller.Section.AddList(Section.GetList());" + Environment.NewLine;

                if (!string.IsNullOrEmpty(ControllerConstructor))
                    TmpMethodCodeTemplateValue += "            controller.CodeBehindConstructor" + ControllerConstructor + ";" + Environment.NewLine;

                TmpMethodCodeTemplateValue += "            controller.PageLoad(context);" + Environment.NewLine + Environment.NewLine;

                TmpMethodCodeTemplateValue += "            ViewData.AddList(controller.ViewData.GetList());" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            if (!string.IsNullOrEmpty(controller.ViewPath))" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "                return LoadPage(controller.ViewPath, context);" + Environment.NewLine + Environment.NewLine;

                TmpMethodCodeTemplateValue += "            if (!string.IsNullOrEmpty(controller.DownloadFilePath))" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            {" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "                Download(context, controller.DownloadFilePath);" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "                return \"\";" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            }" + Environment.NewLine + Environment.NewLine;

                TmpMethodCodeTemplateValue += "            if (!controller.IgnoreViewAndModel)" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            {" + Environment.NewLine;

                if (!string.IsNullOrEmpty(Model))
                {
                    TmpMethodCodeTemplateValue += "                " + Model + " model = (" + Model + ")controller.CodeBehindModel;" + Environment.NewLine;

                    if (ModelUseAbstract)
                    {
                        TmpMethodCodeTemplateValue += "                model.CallerViewPath = CallerViewPath;" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                model.CallerViewDirectoryPath = CallerViewDirectoryPath;" + Environment.NewLine;

                        if (UseSection)
                            TmpMethodCodeTemplateValue += "                model.Section.AddList(Section.GetList());" + Environment.NewLine;
                    }

                    if (!string.IsNullOrEmpty(ModelConstructor))
                        TmpMethodCodeTemplateValue += "                model.CodeBehindConstructor" + ModelConstructor + ";" + Environment.NewLine;

                    if (ModelUseAbstract)
                    {
                        TmpMethodCodeTemplateValue += "                ViewData.AddList(model.ViewData.GetList());" + Environment.NewLine;

                        TmpMethodCodeTemplateValue += "                if (!string.IsNullOrEmpty(model.DownloadFilePath))" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                {" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                    Download(context, model.DownloadFilePath);" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                    return \"\";" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                }" + Environment.NewLine + Environment.NewLine;

                        TmpMethodCodeTemplateValue += "                controller.ResponseText += model.ResponseText;" + Environment.NewLine;
                    }
                }

                TmpMethodCodeTemplateValue += TextToCodeCombination;
                TmpMethodCodeTemplateValue += "            }" + Environment.NewLine + Environment.NewLine;
                
                TmpMethodCodeTemplateValue += "            RequestPath = PreviousRequestPath;" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            CallerViewPath = PreviousCallerViewPath;" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            CallerViewDirectoryPath = PreviousCallerViewDirectoryPath;" + Environment.NewLine + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            return " + (!string.IsNullOrEmpty(Layout) ? "SetPageLoadByFullPath(\"" + Layout + "\", context, controller.ResponseText)" : "controller.ResponseText") + ";" + Environment.NewLine;
            }
            else
            {
                TmpMethodCodeTemplateValue += "            string ReturnValue = \"\";" + Environment.NewLine;

                if (!string.IsNullOrEmpty(Model))
                {
                    TmpMethodCodeTemplateValue += "            " + Model + " model = new " + Model + "();" + Environment.NewLine;

                    if (ModelUseAbstract)
                    {
                        TmpMethodCodeTemplateValue += "                model.CallerViewPath = CallerViewPath;" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                model.CallerViewDirectoryPath = CallerViewDirectoryPath;" + Environment.NewLine;

                        if (UseSection)
                            TmpMethodCodeTemplateValue += "                model.Section.AddList(Section.GetList());" + Environment.NewLine;
                    }

                    if (!string.IsNullOrEmpty(ModelConstructor))
                        TmpMethodCodeTemplateValue += "            model.CodeBehindConstructor" + ModelConstructor + ";" + Environment.NewLine;

                    if (ModelUseAbstract)
                    {

                        TmpMethodCodeTemplateValue += "            ViewData.AddList(model.ViewData.GetList());" + Environment.NewLine;

                        TmpMethodCodeTemplateValue += "                if (!string.IsNullOrEmpty(model.DownloadFilePath))" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                {" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                    Download(context, model.DownloadFilePath);" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                    return \"\";" + Environment.NewLine;
                        TmpMethodCodeTemplateValue += "                }" + Environment.NewLine + Environment.NewLine;

                        TmpMethodCodeTemplateValue += "            ReturnValue += model.ResponseText;" + Environment.NewLine + Environment.NewLine;
                    }
                }

                TmpMethodCodeTemplateValue += TextToCodeCombination + Environment.NewLine;

                TmpMethodCodeTemplateValue += "            RequestPath = PreviousRequestPath;" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            CallerViewPath = PreviousCallerViewPath;" + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            CallerViewDirectoryPath = PreviousCallerViewDirectoryPath;" + Environment.NewLine + Environment.NewLine;
                TmpMethodCodeTemplateValue += "            return " + (!string.IsNullOrEmpty(Layout) ? "SetPageLoadByFullPath(\"" + Layout + "\", context, ReturnValue)" : "ReturnValue") + ";" + Environment.NewLine;
            }

            TmpMethodCodeTemplateValue += "        }" + Environment.NewLine;

            MethodCodeTemplateValue += TmpMethodCodeTemplateValue;
        }

        public void AspxTextAndCodeCombinationStandard(string AspxText, string FilePath, string RootDirectoryPath, int MethodIndexer)
        {
            string AspxFilePath = FilePath.GetTextAfterValue(RootDirectoryPath);

            if (!AspxText.Contains("<%@"))
            {
                ErrorList.Add("Error: Index <%@ not exist in " + AspxFilePath + " file");
                return;
            }

            string PageProperties = " " + AspxText.Split(new string[] { "<%@" }, StringSplitOptions.None)[1].Split("%>")[0] + " ";

            if (!PageProperties.Contains(" Page "))
            {
                ErrorList.Add("Error: Page not exist after index <%@ in " + AspxFilePath + " file");
                return;
            }


            bool PageIsOnlyView = (PageProperties.Trim() == "Page");

            if (!PageIsOnlyView)
                if (!PageProperties.Contains(" Controller=\""))
                    PageIsOnlyView = true;


            // Set Controller
            string Controller = "";
            string ControllerConstructor = "";

            if (!PageIsOnlyView)
            {
                Controller = PageProperties.Split(new string[] { "Controller=\"" }, StringSplitOptions.None)[1].Split("\"")[0];

                // Get Controller Constructor Method
                if (Controller.Contains("("))
                {
                    ControllerConstructor = "(" + Controller.GetTextAfterValue("(").GetTextBeforeLastValue(")").Replace("&quot;", "\"") + ")";
                    Controller = Controller.GetTextBeforeValue("(");
                }

                if (!Controller.ClassPathIsFine())
                {
                    ErrorList.Add("Error: Controller class path is not fine in " + AspxFilePath + " file");
                    return;
                }
            }


            // Set Model
            string Model = (PageProperties.Contains(" Model=\"")) ? PageProperties.Split(new string[] { "Model=\"" }, StringSplitOptions.None)[1].Split("\"")[0] : "";
            string ModelConstructor = "";
            bool ModelUseAbstract = true;

            if (Model != "")
            {
                if (Model.Length > 1)
                    if ((Model[0] == '{') && (Model[Model.Length - 1] == '}'))
                    {
                        Model = Model.Remove(0, 1);
                        Model = Model.Remove(Model.Length - 1, 1);
                        ModelUseAbstract = false;
                    }

                // Get Model Constructor Method
                if (Model.Contains("("))
                {
                    ModelConstructor = "(" + Model.GetTextAfterValue("(").GetTextBeforeLastValue(")").Replace("&quot;", "\"") + ")";
                    Model = Model.GetTextBeforeValue("(");
                }

                if (!Model.ClassPathIsFine())
                {
                    ErrorList.Add("Error: Model class path is not fine in " + AspxFilePath + " file");
                    return;
                }
            }


            // Set Layout
            string Layout = (PageProperties.Contains(" Layout=\"")) ? PageProperties.Split(new string[] { "Layout=\"" }, StringSplitOptions.None)[1].Split("\"")[0] : "";

            if (Layout != "")
            {
                string LayoutPath = "";

                if (Layout[0] == '/' || Layout[0].ToString() == @"\")
                    LayoutPath = RootDirectoryPath + @"\" + Layout;
                else
                    LayoutPath = FilePath.GetTextBeforeLastValue(@"\") + @"\" + Layout;

                if (!Path.HasExtension(LayoutPath))
                {
                    Layout += ".aspx";
                    LayoutPath += ".aspx";
                }

                if (Path.GetExtension(LayoutPath) != ".aspx")
                {
                    ErrorList.Add("Error: Layout extension is not valid in " + AspxFilePath + " file");
                    return;
                }

                if (!File.Exists(LayoutPath))
                {
                    ErrorList.Add("Error: Layout file is not exist in " + LayoutPath + " path");
                    return;
                }
            }


            // Set If Is Layout
            string TmpIsLayout = (PageProperties.Contains(" IsLayout=\"")) ? PageProperties.Split(new string[] { "IsLayout=\"" }, StringSplitOptions.None)[1].Split("\"")[0] : "";
            bool IsLayout = (TmpIsLayout == "true");


            // Set Break
            string Break = (PageProperties.Contains(" Break=\"")) ? PageProperties.Split(new string[] { "Break=\"" }, StringSplitOptions.None)[1].Split("\"")[0] : "";
            bool IsBreak = (Break == "true");


            // Set Break
            string Section = (PageProperties.Contains(" Section=\"")) ? PageProperties.Split(new string[] { "Section=\"" }, StringSplitOptions.None)[1].Split("\"")[0] : "";
            bool UseSection = (Section == "true");


            // Set Global Template
            AspxText = GlobalTemplate + AspxText;

            // Set Template
            string Template = (PageProperties.Contains(" Template=\"")) ? PageProperties.Split(new string[] { "Template=\"" }, StringSplitOptions.None)[1].Split("\"")[0] : "";

            if (Template != "")
            {
                string[] Templates = Template.Split(';');

                foreach (string TmpTemplate in Templates)
                {
                    Template = TmpTemplate;

                    string TemplatePath = "";

                    if (Template[0] == '/' || Template[0].ToString() == @"\")
                        TemplatePath = RootDirectoryPath + @"\" + Template;
                    else
                        TemplatePath = FilePath.GetTextBeforeLastValue(@"\") + @"\" + Template;

                    if (!Path.HasExtension(TemplatePath))
                        TemplatePath += ".astx";

                    if (Path.GetExtension(TemplatePath) != ".astx")
                    {
                        ErrorList.Add("Error: Template extension is not valid in " + AspxFilePath + " file");
                        return;
                    }

                    if (!File.Exists(TemplatePath))
                    {
                        ErrorList.Add("Error: Template file is not exist in " + TemplatePath + " path");
                        return;
                    }

                    string AstxText = "";
                    var Lines = File.OpenText(TemplatePath);
                    var TmpLine = "";
                    while ((TmpLine = Lines.ReadLine()) != null)
                    {
                        AstxText += TmpLine + '\n';
                    }

                    AspxText = AstxText + AspxText;
                }
            }

            string TextToCodeCombination = "";

            // Clear Page Properties
            while (AspxText.Contains("<%@"))
            {
                if (!AspxText.Contains("%>"))
                {
                    ErrorList.Add("Error: Index <%@ not closed %> for clear in " + AspxFilePath + " file");
                    break;
                }

                string InnerText = AspxText.Split(new string[] { "<%@" }, StringSplitOptions.None)[1].Split("%>")[0];

                AspxText = AspxText.Replace("<%@" + InnerText + "%>", "");
            }


            // Fetch Template
            string TmpAspxText = AspxText;
            while (TmpAspxText.Contains("<#"))
            {
                TmpAspxText = "<#" + TmpAspxText.GetTextAfterValue("<#");

                if (!TmpAspxText.Contains("#>"))
                {
                    ErrorList.Add("Error: Index <# not closed #> for code combination in " + AspxFilePath + " file");
                    break;
                }

                if (TmpAspxText.Length < 1)
                    break;

                CodeBehindFetchStandardSyntex syntex1 = new CodeBehindFetchStandardSyntex();
                string InnerText = syntex1.FetchInnerText(TmpAspxText, "<#", "#>");

                string PartName = GetTemplatePartName(InnerText);
                char CharacterAfterTemplatePartName = GetCharacterAfterTemplatePartName(InnerText);
                bool PartHasTemplate = PartHasTemplateValue(InnerText);

                if (PartHasTemplate)
                {
                    string TmpInnerTextForReplace = InnerText;

                    if (AspxText.Contains("<#" + PartName + "="))
                    {
                        CodeBehindFetchStandardSyntex syntex2 = new CodeBehindFetchStandardSyntex();
                        string ReturnedInnerText = syntex2.FetchInnerText("<#" + PartName + "=" + AspxText.GetTextAfterValue("<#" + PartName + "="), "<#", "#>");

                        if (InnerText.Contains("<#" + PartName + "#>"))
                        {
                            AspxText = AspxText.Replace("<#" + InnerText + "#>", "");

                            string TmpInnerTextForCodeBlock = InnerText;
                            while (TmpInnerTextForCodeBlock.Contains("<%"))
                            {
                                if (!TmpInnerTextForCodeBlock.Contains("%>"))
                                {
                                    ErrorList.Add("Error: Index <% not closed %> in template part " + PartName + " for code combination in " + AspxFilePath + " file");
                                    break;
                                }

                                string TmpNewInnerText = TmpInnerTextForCodeBlock.Split(new string[] { "<%" }, StringSplitOptions.None)[1].Split("%>")[0];

                                if (TmpNewInnerText.Contains("<#" + PartName + "#>"))
                                {
                                    if (TmpNewInnerText[0] == '=')
                                        TmpInnerTextForReplace = TmpInnerTextForReplace.Replace("<#" + PartName + "#>", "%>" + "<#" + PartName + "#>" + "<%=");
                                    else
                                        TmpInnerTextForReplace = TmpInnerTextForReplace.Replace("<#" + PartName + "#>", "%>" + "<#" + PartName + "#>" + "<%");
                                }

                                var regex2 = new Regex(Regex.Escape("<%" + TmpNewInnerText + "%>"));
                                TmpInnerTextForCodeBlock = regex2.Replace(TmpInnerTextForCodeBlock, "", 1);
                            }
                        }

                        if (!ReturnedInnerText.Contains("<#" + PartName + "#>"))
                            TmpInnerTextForReplace = TmpInnerTextForReplace.Replace("<#" + PartName + "#>", ReturnedInnerText.GetTextAfterValue("="));

                        string TmpInnerTextValue;
                        if (CharacterAfterTemplatePartName == '<')
                            TmpInnerTextValue = TmpInnerTextForReplace.GetTextAfterValue(PartName);
                        else
                            TmpInnerTextValue = TmpInnerTextForReplace.GetTextAfterValue(CharacterAfterTemplatePartName.ToString());

                        AspxText = AspxText.Replace("<#" + ReturnedInnerText + "#>", TmpInnerTextValue);
                    }

                    string InnerTextValue;
                    if (CharacterAfterTemplatePartName == '<')
                        InnerTextValue = TmpInnerTextForReplace.GetTextAfterValue(PartName);
                    else
                        InnerTextValue = TmpInnerTextForReplace.GetTextAfterValue(CharacterAfterTemplatePartName.ToString());

                    if (!InnerTextValue.Contains("<#" + PartName + "#>"))
                    {
                        AspxText = AspxText.Replace('{' + "<#" + PartName + "#>" + '}', InnerTextValue.Replace("\"", @"\" + "\"").Replace('\n'.ToString(), @"\" + "n"));
                        AspxText = AspxText.Replace("<#" + PartName + "#>", InnerTextValue);
                    }

                    var regex = new Regex(Regex.Escape("<#" + InnerText + "#>"));
                    AspxText = regex.Replace(AspxText, "", 1);
                }

                if (syntex1.FindSyntex)
                    TmpAspxText = TmpAspxText.Remove(syntex1.StartSyntex, syntex1.EndSyntex - syntex1.StartSyntex);
                else
                    TmpAspxText = TmpAspxText.Replace("<#" + InnerText + "#>", "");
            }


            // Set Trim Option
            FullTrim ft = new FullTrim();
            if (StartTrimInAspxFile)
                AspxText = ft.FullTrimInStart(AspxText);
            if (EndTrimInAspxFile)
                AspxText = ft.FullTrimInEnd(AspxText);
            if (InnerTrimInAspxFile)
                AspxText = AspxText.Replace('\n' + "<%", "<%");

            bool RemoveFirstEmptyLine = false;
            if (AspxText.Length > 4 && StartTrimInAspxFile)
                if (AspxText.Substring(0, 2) == "<%")
                    RemoveFirstEmptyLine = true;

            // Code Combination
            while (AspxText.Contains("<%"))
            {
                // Set Remove First Empty Line
                if (RemoveFirstEmptyLine)
                {
                    if (AspxText.Length > 1)
                        if (AspxText[0] == ('\n'))
                            AspxText = AspxText.Remove(0, 1);

                    RemoveFirstEmptyLine = false;
                }

                TextToCodeCombination += GetWriteText(AspxText.GetTextBeforeValue("<%"), PageIsOnlyView);

                AspxText = "<%" + AspxText.GetTextAfterValue("<%");

                if (!AspxText.Contains("%>"))
                {
                    ErrorList.Add("Error: Index <% not closed %> for code combination in " + AspxFilePath + " file");
                    break;
                }

                string InnerText = AspxText.Split(new string[] { "<%" }, StringSplitOptions.None)[1].Split("%>")[0];

                if (InnerText.Length > 0)
                    if (InnerText[0] == '=')
                    {
                        TextToCodeCombination += GetWriteCode(InnerText.Remove(0, 1), PageIsOnlyView);
                    }
                    else
                        TextToCodeCombination += GetAddCode(InnerText, PageIsOnlyView);

                var regex = new Regex(Regex.Escape("<%" + InnerText + "%>"));
                AspxText = regex.Replace(AspxText, "", 1);
            }

            TextToCodeCombination += GetWriteText(AspxText, PageIsOnlyView);

            SetMethod(AspxFilePath, Controller, ControllerConstructor, Model, ModelConstructor, ModelUseAbstract,!PageIsOnlyView, Layout, IsLayout, IsBreak, UseSection, MethodIndexer, TextToCodeCombination);
        }

        public void AspxTextAndCodeCombinationRazor(string AspxText, string FilePath, string RootDirectoryPath, int MethodIndexer)
        {
            string AspxFilePath = FilePath.GetTextAfterValue(RootDirectoryPath);

            CodeBehindFetchRazorSyntex syntex = new CodeBehindFetchRazorSyntex();

            FullTrim ft = new FullTrim();
            AspxText = ft.FullTrimInStart(AspxText);

            // Fetch Page
            if (AspxText.Length < 5)
            {
                ErrorList.Add("Error: Index @page not exist for code combination in " + AspxFilePath + " file");
                return;
            }

            if (AspxText.Substring(0, 5) != "@page")
            {
                ErrorList.Add("Error: Index @page not exist for code combination in " + AspxFilePath + " file");
                return;
            }

            AspxText = AspxText.Remove(0, 5);


            // Fetch Page Attribute
            string Controller = "";
            string Model = "";
            string Layout = "";
            bool IsLayout = false;
            bool IsBreak = false;
            bool UseSection = false;
            string Template = "";

            string[] AspxLine = AspxText.Split('\n');
            foreach (string line in AspxLine)
            {
                string TmpLine = ft.FullTrimAll(line);

                if (TmpLine.Length == 0)
                    continue;

                if (TmpLine[0] != '@')
                    break;

                // Fetch Controller, Model, Layout, IsLayout, IsBreak, UseSection, Template
                if (TmpLine.StartsWith("@controller"))
                {
                    Controller = ft.FullTrimAll(TmpLine.GetTextAfterValue("@controller"));
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else if (TmpLine.StartsWith("@model"))
                {
                    Model = ft.FullTrimAll(TmpLine.GetTextAfterValue("@model"));
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else if (TmpLine.StartsWith("@layout"))
                {
                    Layout = ft.FullTrimAll(TmpLine.GetTextAfterValue("@layout"));
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else if (TmpLine == "@islayout")
                {
                    IsLayout = true;
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else if (TmpLine == "@break")
                {
                    IsBreak = true;
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else if (TmpLine == "@section")
                {
                    UseSection = true;
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else if (TmpLine.StartsWith("@template"))
                {
                    Template = ft.FullTrimAll(TmpLine.GetTextAfterValue("@template"));
                    AspxText = AspxText.GetTextAfterValue(line);
                    continue;
                }
                else
                    break;
            }


            // Set Controller
            string ControllerConstructor = "";
            bool ControllerIsSet = false;
            if (Controller != "")
            {
                // Get Controller Constructor Method
                if (Controller.Contains("("))
                {
                    ControllerConstructor = "(" + Controller.GetTextAfterValue("(").GetTextBeforeLastValue(")") + ")";
                    Controller = Controller.GetTextBeforeValue("(");
                }

                if (!Controller.ClassPathIsFine())
                {
                    ErrorList.Add("Error: Controller class path is not fine in " + AspxFilePath + " file");
                    return;
                }

                ControllerIsSet = true;
            }


            // Set Model
            string ModelConstructor = "";
            bool ModelUseAbstract = true;

            if (Model != "")
            {
                if (Model.Length > 1)
                    if ((Model[0] == '{') && (Model[Model.Length - 1] == '}'))
                    {
                        Model = Model.Remove(0, 1);
                        Model = Model.Remove(Model.Length - 1, 1);
                        ModelUseAbstract = false;
                    }

                // Get Model Constructor Method
                if (Model.Contains("("))
                {
                    ModelConstructor = "(" + Model.GetTextAfterValue("(").GetTextBeforeLastValue(")") + ")";
                    Model = Model.GetTextBeforeValue("(");
                }

                if (!Model.ClassPathIsFine())
                {
                    ErrorList.Add("Error: Model class path is not fine in " + AspxFilePath + " file");
                    return;
                }
            }


            // Set Layout
            if (Layout != "")
            {
                if (Layout.Length < 2)
                {
                    ErrorList.Add("Error: The layout content is not specified correctly in " + AspxFilePath + " path");
                    return;
                }

                if (!Layout.StartsWith('"') )
                {
                    ErrorList.Add("Error: The layout content value does not start with double quotes in " + AspxFilePath + " file");
                    return;
                }

                if (!Layout.EndsWith('"') )
                {
                    ErrorList.Add("Error: The layout content value does not end with double quotes in " + AspxFilePath + " file");
                    return;
                }

                Layout = Layout.Remove(0, 1);
                Layout = Layout.Remove(Layout.Length - 1, 1);

                string LayoutPath = "";

                if (Layout[0] == '/' || Layout[0].ToString() == @"\")
                    LayoutPath = RootDirectoryPath + @"\" + Layout;
                else
                    LayoutPath = FilePath.GetTextBeforeLastValue(@"\") + @"\" + Layout;

                if (!Path.HasExtension(LayoutPath))
                {
                    Layout += ".aspx";
                    LayoutPath += ".aspx";
                }

                if (Path.GetExtension(LayoutPath) != ".aspx")
                {
                    ErrorList.Add("Error: Layout extension is not valid in " + AspxFilePath + " file");
                    return;
                }

                if (!File.Exists(LayoutPath))
                {
                    ErrorList.Add("Error: Layout file is not exist in " + LayoutPath + " path");
                    return;
                }
            }
          
            // Set Global Template
            AspxText = GlobalTemplate + AspxText;

            // Set Template
            if (Template != "")
            {
                if (Template.Length < 2)
                {
                    ErrorList.Add("Error: The template content is not specified correctly in " + AspxFilePath + " path");
                    return;
                }

                if (!Template.StartsWith('"'))
                {
                    ErrorList.Add("Error: The template content value does not start with double quotes in " + AspxFilePath + " file");
                    return;
                }

                if (!Template.EndsWith('"'))
                {
                    ErrorList.Add("Error: The template content value does not end with double quotes in " + AspxFilePath + " file");
                    return;
                }

                Template = Template.Remove(0, 1);
                Template = Template.Remove(Template.Length - 1, 1);

                string[] Templates = Template.Split(';');

                foreach (string TmpTemplate in Templates)
                {
                    Template = TmpTemplate;

                    string TemplatePath = "";

                    if (Template[0] == '/' || Template[0].ToString() == @"\")
                        TemplatePath = RootDirectoryPath + @"\" + Template;
                    else
                        TemplatePath = FilePath.GetTextBeforeLastValue(@"\") + @"\" + Template;

                    if (!Path.HasExtension(TemplatePath))
                        TemplatePath += ".astx";

                    if (Path.GetExtension(TemplatePath) != ".astx")
                    {
                        ErrorList.Add("Error: Template extension is not valid in " + AspxFilePath + " file");
                        return;
                    }

                    if (!File.Exists(TemplatePath))
                    {
                        ErrorList.Add("Error: Template file is not exist in " + TemplatePath + " path");
                        return;
                    }

                    string AstxText = "";
                    var Lines = File.OpenText(TemplatePath);
                    var TmpLine = "";
                    while ((TmpLine = Lines.ReadLine()) != null)
                    {
                        AstxText += TmpLine + '\n';
                    }

                    AspxText = AstxText + AspxText;
                }
            }

            // Fetch Template
            string TmpAspxText = AspxText;
            while (TmpAspxText.Contains("@#"))
            {
                TmpAspxText = "@#" + TmpAspxText.GetTextAfterValue("@#");

                if (TmpAspxText.Length < 1)
                    break;

                string PartName = "";
                char CharacterAfterTemplatePartName = '\0';

                for (int i = 2; i < TmpAspxText.Length; i++)
                {
                    if (char.IsLetter(TmpAspxText[i]) || char.IsNumber(TmpAspxText[i]))
                        PartName += TmpAspxText[i];
                    else
                    {
                        CharacterAfterTemplatePartName = TmpAspxText[i];
                        break;
                    }
                }

                if (string.IsNullOrEmpty(PartName))
                {
                    ErrorList.Add("Error: Name not set after Index @# for code combination in " + AspxFilePath + " file");
                    break;
                }

                bool PartHasTemplate = (CharacterAfterTemplatePartName == '{');

                CodeBehindFetchRazorSyntex syntex1 = new CodeBehindFetchRazorSyntex();
                string InnerText = "";
                    
                if (PartHasTemplate)
                    InnerText = syntex1.FetchSyntexWithEndedCharacterText("@" + TmpAspxText.Remove(0, PartName.Length + 2));
                else
                    InnerText = syntex1.FetchExpressions(TmpAspxText.Remove(1, 1)); // Remove Sharp (#)

                if (PartHasTemplate)
                {
                    string TmpInnerTextForReplace = InnerText;
                    bool HasPartName = false;

                    if (AspxText.Contains("@#" + PartName + "="))
                    {
                        CodeBehindFetchRazorSyntex syntex2 = new CodeBehindFetchRazorSyntex();
                        string ReturnedInnerText = syntex2.FetchSyntexWithEndedCharacterText("@" + AspxText.GetTextAfterValue("@#" + PartName + "="));

                        // Contains Part Name
                        HasPartName = false;
                        string TmpInnerText = InnerText;
                        while (TmpInnerText.Contains("@#" + PartName))
                        {
                            TmpInnerText = TmpInnerText.GetTextAfterValue("@#" + PartName) + '\\';

                            char TmpCharacter = TmpInnerText[0];
                            if (!char.IsLetter(TmpCharacter) && !char.IsNumber(TmpCharacter))
                            {
                                HasPartName = true;
                                break;
                            }
                        }

                        if (HasPartName)
                            AspxText = AspxText.Replace("@#" + PartName + "{" + InnerText + "}", "");


                        // Check Exist @#Template In @#Template={*}
                        HasPartName = false;
                        string TmpReturnedInnerText = ReturnedInnerText;
                        while (TmpReturnedInnerText.Contains("@#" + PartName))
                        {
                            TmpReturnedInnerText = TmpReturnedInnerText.GetTextAfterValue("@#" + PartName) + '\\';

                            char TmpCharacter = TmpReturnedInnerText[0];
                            if (!char.IsLetter(TmpCharacter) && !char.IsNumber(TmpCharacter))
                            {
                                HasPartName = true;
                                break;
                            }
                        }

                        if (!HasPartName)
                        {
                            string TmpReturnedInnerText2 = TmpInnerTextForReplace;
                            while (TmpReturnedInnerText2.Contains("@#" + PartName))
                            {
                                TmpReturnedInnerText2 = TmpReturnedInnerText2.GetTextAfterValue("@#" + PartName);

                                if (TmpReturnedInnerText2.Length > 0)
                                {
                                    char TmpCharacter = TmpReturnedInnerText2[0];
                                    if (!char.IsLetter(TmpCharacter) && !char.IsNumber(TmpCharacter))
                                        TmpInnerTextForReplace = TmpInnerTextForReplace.Replace("@#" + PartName + TmpCharacter, ReturnedInnerText + TmpCharacter);
                                }
                                else
                                    TmpInnerTextForReplace = TmpInnerTextForReplace.Replace("@#" + PartName, ReturnedInnerText);
                            }
                        }

                        AspxText = AspxText.Replace("@#" + PartName + "={" + ReturnedInnerText + "}", TmpInnerTextForReplace);
                    }

                    string InnerTextValue = TmpInnerTextForReplace;

                    HasPartName = false;
                    string TmpInnerTextValue1 = InnerTextValue;
                    while (TmpInnerTextValue1.Contains("@#" + PartName))
                    {
                        TmpInnerTextValue1 = TmpInnerTextValue1.GetTextAfterValue("@#" + PartName) + '\\';

                        char TmpCharacter = TmpInnerTextValue1[0];
                        if (!char.IsLetter(TmpCharacter) && !char.IsNumber(TmpCharacter))
                        {
                            HasPartName = true;
                            break;
                        }
                    }

                    if (!HasPartName)
                    {
                        string TmpAspxText2 = AspxText;
                        while (TmpAspxText2.Contains("@#" + PartName))
                        {
                            TmpAspxText2 = TmpAspxText2.GetTextAfterValue("@#" + PartName);

                            if (TmpAspxText2.Length > 0)
                            {
                                char TmpCharacter = TmpAspxText2[0];
                                if (!char.IsLetter(TmpCharacter) && !char.IsNumber(TmpCharacter) && TmpCharacter != '{' && TmpCharacter != '=')
                                {
                                    AspxText = AspxText.Replace('{' + "@#" + PartName + '}', InnerTextValue.Replace("\"", @"\" + "\"").Replace('\n'.ToString(), @"\" + "n"));
                                    AspxText = AspxText.Replace("@#" + PartName + TmpCharacter, InnerTextValue + TmpCharacter);
                                }
                            }
                            else
                            {
                                AspxText = AspxText.Replace('{' + "@#" + PartName + '}', InnerTextValue.Replace("\"", @"\" + "\"").Replace('\n'.ToString(), @"\" + "n"));
                                AspxText = AspxText.Replace("@#" + PartName, InnerTextValue);
                            }
                        }
                    }

                    if (PartHasTemplate)
                    {
                        var regex = new Regex(Regex.Escape("@#" + PartName + ((CharacterAfterTemplatePartName == '=') ? "=" : "") + "{" + InnerText + "}"));
                        AspxText = regex.Replace(AspxText, "", 1);
                    }
                    else
                    {
                        var regex = new Regex(Regex.Escape("@#" + PartName + CharacterAfterTemplatePartName));
                        AspxText = regex.Replace(AspxText, CharacterAfterTemplatePartName.ToString(), 1);
                    }
                }

                if (InnerText.Length > 0)
                {
                    int TemplateLength = 0;

                    if (PartHasTemplate)
                    {
                        if (CharacterAfterTemplatePartName == '=')
                            TemplateLength = InnerText.Length + PartName.Length + 5;

                        if (CharacterAfterTemplatePartName == '{')
                            TemplateLength = InnerText.Length + PartName.Length + 4;
                    }
                    else
                        TemplateLength = PartName.Length + 2;

                    TmpAspxText = TmpAspxText.Remove(0, TemplateLength);
                }
                else
                    if (PartHasTemplate)
                        TmpAspxText = TmpAspxText.Replace("@#" + PartName + ((CharacterAfterTemplatePartName == '=') ? "=" : "") + "{" + InnerText + "}", "");
                    else
                        TmpAspxText = TmpAspxText.Replace("@#" + PartName + CharacterAfterTemplatePartName, CharacterAfterTemplatePartName.ToString());
            }


            // Set Trim Option
            if (StartTrimInAspxFile)
                AspxText = ft.FullTrimInStart(AspxText);
            if (EndTrimInAspxFile)
                AspxText = ft.FullTrimInEnd(AspxText);
            if (InnerTrimInAspxFile)
                AspxText = AspxText.Replace('\n' + "@{", "@{");


            // Clean Razor Comments
            TmpAspxText = AspxText;
            while (TmpAspxText.Contains("@*"))
            {
                TmpAspxText = TmpAspxText.GetTextAfterValue("@*");

                if (!TmpAspxText.Contains("*@"))
                {
                    // ErrorList.Add("Error: Index @* not closed @* for code combination in " + AspxFilePath + " file");
                    break;
                }

                string Comment = AspxText.Split(new string[] { "@*" }, StringSplitOptions.None)[1].Split("*@")[0];

                AspxText = AspxText.Replace(Comment, "");
            }


            // Remove First Empty Line
            bool RemoveFirstEmptyLine = false;
            if (AspxText.Length > 1 && StartTrimInAspxFile)
                if (AspxText[0] == '@')
                    RemoveFirstEmptyLine = true;


            string TextToCodeCombination = "";
            bool HasElseIf = false;

            string TextForWrite = "";
            for (int i = 0; i < AspxText.Length; i++)
            {
                if (AspxText[i] == '@')
                {
                    // Set Remove First Empty Line
                    if (RemoveFirstEmptyLine && (i > 0))
                    {
                        if (TextForWrite.Length > 1)
                            if (TextForWrite[0] == '\n')
                                TextForWrite = TextForWrite.Remove(0, 1);

                        RemoveFirstEmptyLine = false;
                    }

                    TextToCodeCombination += GetWriteText(TextForWrite, !ControllerIsSet);
                    TextForWrite = "";

                    if ((i + 1) < AspxText.Length)
                    {
                        // Escape Email Address
                        if ((i > 0) && (AspxText[i + 1] != '('))
                        {
                            if ((char.IsLetter(AspxText[i - 1]) || char.IsNumber(AspxText[i - 1])) && (char.IsLetter(AspxText[i + 1]) || char.IsNumber(AspxText[i + 1])))
                            {
                                TextForWrite += "@";
                                continue;
                            }
                        }

                        // Escape Symbol For Double AtSign (@@)
                        if (AspxText[i + 1] == '@')
                        {
                            TextForWrite += "@";
                            i++;
                            continue;
                        }

                        if (AspxText[i + 1] == '(')
                        {
                            TextToCodeCombination += GetWriteCode(syntex.FetchSyntexWithEndedCharacter(AspxText.Substring(i)), !ControllerIsSet);

                            i += syntex.RazorIndexLength - 1;
                            continue;
                        }

                        // If Detection
                        if (char.IsLetter(AspxText[i + 1]))
                        {
                            if (i + 5 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 2) == "if" && (AspxText[i + 3] == ' ' || AspxText[i + 3] == '(' || AspxText[i + 3] == '\n' || AspxText[i + 3] == '\t' || AspxText[i + 3] == '\r'))
                                {
                                    i += 1;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode((HasElseIf? "else " : "") + "if (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);
                                        HasElseIf = false;

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    if ((i + 1) < AspxText.Length)
                                    {
                                        string TmpAspxTextForFindElse = ft.FullTrimInStart(AspxText.Substring(i + 1));

                                        if (TmpAspxTextForFindElse.Length < 4)
                                            continue;

                                        if (TmpAspxTextForFindElse.Substring(0, 4) != "else")
                                            continue;
                                    }


                                    int ElseIndex = i - 1;
                                    while (ElseIndex + 1 < AspxText.Length)
                                    {
                                        if (AspxText[++ElseIndex] != 'e')
                                            continue;

                                        if (ElseIndex + 7 < AspxText.Length)
                                            if (AspxText.Substring(ElseIndex, 4) == "else" && (AspxText[ElseIndex + 4] == ' ' || AspxText[ElseIndex + 4] == '\n' || AspxText[ElseIndex + 4] == '\t' || AspxText[ElseIndex + 4] == '\r'))
                                            {
                                                i = ElseIndex;

                                                int ElseIfIndex = i + 4;
                                                for (; (ElseIfIndex + 2) < AspxText.Length; ElseIfIndex++)
                                                {
                                                    if (AspxText[ElseIfIndex] == 'i' && AspxText[ElseIfIndex + 1] == 'f' && (AspxText[ElseIfIndex + 2] == ' ' || AspxText[ElseIfIndex + 2] == '(' || AspxText[ElseIfIndex + 2] == '\n' || AspxText[ElseIfIndex + 2] == '\t' || AspxText[ElseIfIndex + 2] == '\r'))
                                                    {
                                                        HasElseIf = true;
                                                        break;
                                                    }
                                                }

                                                if (HasElseIf)
                                                {
                                                    AspxText = AspxText.Insert(ElseIfIndex, "@");
                                                    i += 4;
                                                    break;
                                                }


                                                i += 3;

                                                TextToCodeCombination += GetAddCode("else", !ControllerIsSet);

                                                while (i < AspxText.Length)
                                                {
                                                    if (AspxText[++i] != '{')
                                                        continue;

                                                    TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                                    syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                                    foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                                    {
                                                        switch (nv.Name)
                                                        {
                                                            case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                            case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                            case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                                        }
                                                    }

                                                    TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                                    i += syntex.RazorIndexLength - 3;

                                                    break;
                                                }
                                            }
                                        break;
                                    }

                                    continue;
                                }

                            // Do While Detection
                            if (i + 5 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 2) == "do" && (AspxText[i + 3] == ' ' || AspxText[i + 3] == '\n'|| AspxText[i + 3] == '\t'||AspxText[i + 3] == '\r'))
                                {
                                    i += 1;

                                    TextToCodeCombination += GetAddCode("do", !ControllerIsSet);

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    while (i + 1 < AspxText.Length)
                                    {
                                        bool BreakWhile = false;

                                        if (AspxText[++i] != 'w')
                                            continue;

                                        if (i + 8 < AspxText.Length)
                                            if (AspxText.Substring(i, 5) == "while" && (AspxText[i + 5] == ' ' || AspxText[i + 5] == '(' || AspxText[i + 5] == '\n' || AspxText[i + 5] == '\t' || AspxText[i + 5] == '\r'))
                                            {
                                                i += 5;

                                                while (i < AspxText.Length)
                                                {
                                                    if (AspxText[++i] != '(')
                                                        continue;

                                                    TextToCodeCombination += GetAddCode("while (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ");", !ControllerIsSet);

                                                    i += syntex.RazorIndexLength - 1;

                                                    BreakWhile = true;
                                                    break;
                                                }
                                            }

                                        if (BreakWhile)
                                            break;
                                    }

                                    continue;
                                }

                            // For Detection
                            if (i + 6 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 3) == "for" && (AspxText[i + 4] == ' ' || AspxText[i + 4] == '(' || AspxText[i + 4] == '\n' || AspxText[i + 4] == '\t' || AspxText[i + 4] == '\r'))
                                {
                                    i += 2;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode("for (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    continue;
                                }

                            // Lock Detection
                            if (i + 7 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 4) == "lock" && (AspxText[i + 5] == ' ' || AspxText[i + 5] == '(' || AspxText[i + 5] == '\n' || AspxText[i + 5] == '\t' || AspxText[i + 5] == '\r'))
                                {
                                    i += 3;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode("lock (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    continue;
                                }

                            // While Detection
                            if (i + 8 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 5) == "while" && (AspxText[i + 6] == ' ' || AspxText[i + 6] == '(' || AspxText[i + 6] == '\n' || AspxText[i + 6] == '\t' || AspxText[i + 6] == '\r'))
                                {
                                    i += 4;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode("while (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    continue;
                                }

                            // Using Detection
                            if (i + 8 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 5) == "using" && (AspxText[i + 6] == ' ' || AspxText[i + 6] == '(' || AspxText[i + 6] == '\n' || AspxText[i + 6] == '\t' || AspxText[i + 6] == '\r'))
                                {
                                    i += 4;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode("using (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    continue;
                                }

                            // Switch Detection
                            if (i + 9 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 6) == "switch" && (AspxText[i + 7] == ' ' || AspxText[i + 7] == '(' || AspxText[i + 7] == '\n' || AspxText[i + 7] == '\t' || AspxText[i + 7] == '\r'))
                                {
                                    i += 5;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode("switch (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    continue;
                                }

                            // Foreach Detection
                            if (i + 10 < AspxText.Length)
                                if (AspxText.Substring(i + 1, 7) == "foreach" && (AspxText[i + 8] == ' ' || AspxText[i + 8] == '(' || AspxText[i + 8] == '\n' || AspxText[i + 8] == '\t' || AspxText[i + 8] == '\r'))
                                {
                                    i += 6;

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '(')
                                            continue;

                                        TextToCodeCombination += GetAddCode("foreach (" + syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i)) + ")", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 1;

                                        break;
                                    }

                                    while (i < AspxText.Length)
                                    {
                                        if (AspxText[++i] != '{')
                                            continue;

                                        TextToCodeCombination += GetAddCode("{", !ControllerIsSet);

                                        syntex.FetchSyntexWithEndedCharacter("@" + AspxText.Substring(i));

                                        foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                                        {
                                            switch (nv.Name)
                                            {
                                                case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                                case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet, true); break;
                                                case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet, true); break;
                                            }
                                        }

                                        TextToCodeCombination += GetAddCode("}", !ControllerIsSet);

                                        i += syntex.RazorIndexLength - 3;

                                        break;
                                    }

                                    continue;
                                }

                            // Fetch Expressions
                            TextToCodeCombination += GetWriteCode(syntex.FetchExpressions(AspxText.Substring(i)), !ControllerIsSet);

                            i += syntex.ExpressionsIndexLength - 1;
                            continue;
                        }

                        if (AspxText[i + 1] == '{')
                        {
                            syntex.FetchSyntexWithEndedCharacter(AspxText.Substring(i));

                            foreach (NameValue nv in syntex.AddedTextForEndedCharacter.GetList())
                            {
                                switch (nv.Name)
                                {
                                    case "add_code": TextToCodeCombination += GetAddCode(nv.Value, !ControllerIsSet); break;
                                    case "write_code": TextToCodeCombination += GetWriteCode(nv.Value, !ControllerIsSet); break;
                                    case "write_text": TextToCodeCombination += GetWriteText(nv.Value, !ControllerIsSet); break;
                                }
                            }

                            i += syntex.RazorIndexLength - 2;
                            continue;
                        }
                    }
                }
                else
                    TextForWrite += AspxText[i];
            }

            // Set Remove First Empty Line
            if (RemoveFirstEmptyLine)
            {
                if (TextForWrite.Length > 0)
                    if (TextForWrite[0] == ('\n'))
                        TextForWrite = TextForWrite.Remove(0, 1);

                RemoveFirstEmptyLine = false;
            }

            TextToCodeCombination += GetWriteText(TextForWrite, !ControllerIsSet);

            SetMethod(AspxFilePath, Controller, ControllerConstructor, Model, ModelConstructor, ModelUseAbstract, ControllerIsSet, Layout, IsLayout, IsBreak, UseSection, MethodIndexer, TextToCodeCombination);
        }

        public string GetWriteText(string Text, bool PageIsOnlyView, bool IsInsideControl = false)
        {
            if (Text.Length > 0)
            {
                Text = Text.Replace("\\", "\\\\");

                Text = Text.Replace("\"", @"\" + "\"");

                Text = Text.Replace('\n'.ToString(), "\\" + "n");

                string TmpTab = (IsInsideControl) ? "    " : "";

                if (!PageIsOnlyView)
                    return TmpTab + "                controller.ResponseText += \"" + Text + "\";" + Environment.NewLine;
                else
                    return TmpTab + "            ReturnValue += \"" + Text + "\";" + Environment.NewLine;
            }
            else
                return "";
        }

        public string GetWriteCode(string Code, bool PageIsOnlyView, bool IsInsideControl = false)
        {
            string TmpTab = (IsInsideControl) ? "    " : "";

            if (!PageIsOnlyView)
                return TmpTab + "                controller.ResponseText += " + Code + ";" + Environment.NewLine;
            else
                return TmpTab + "            ReturnValue += " + Code + ";" + Environment.NewLine;
        }

        public string GetAddCode(string Code, bool PageIsOnlyView)
        {
            if (!PageIsOnlyView)
                return "                " + Code.Replace('\n'.ToString(), Environment.NewLine + "            ") + Environment.NewLine;
            else
                return "            " + Code.Replace('\n'.ToString(), Environment.NewLine + "            ") + Environment.NewLine;
        }

        private void SaveError(List<string> ErrorList)
        {
            if (!Directory.Exists("code_behind"))
                Directory.CreateDirectory("code_behind");

            // Create views_error.log File
            if (ErrorList.Count > 0)
            {
                const string FilePath = "code_behind/views_class_aggregation_error.log";

                var file = File.CreateText(FilePath);

                file.WriteLine("date_and_time:" + DateTime.Now.ToString());

                foreach (string line in ErrorList)
                {
                    file.WriteLine(line);
                }

                file.Dispose();
                file.Close();
            }
        }

        private void FillGlobalTemplate()
        {
            if (!Directory.Exists("code_behind"))
                Directory.CreateDirectory("code_behind");

            const string FilePath = "code_behind/global_template.astx";

            if (!File.Exists(FilePath))
            {
                File.Create(FilePath).Close();
                return;
            }

            var Lines = File.OpenText(FilePath);
            var TmpLine = "";
            while ((TmpLine = Lines.ReadLine()) != null)
            {
                GlobalTemplate += TmpLine + '\n';
            }
        }

        private void MoveViewFromWwwroot(string ViewPath, string Extension)
        {
            if (!Directory.Exists("wwwroot"))
                return;

            DirectoryInfo WwwrootDir = new DirectoryInfo("wwwroot");

            if (!Directory.Exists(Path.GetFullPath(ViewPath)))
                Directory.CreateDirectory(Path.GetFullPath(ViewPath));

            foreach (FileInfo file in WwwrootDir.GetFiles("*." + Extension, SearchOption.AllDirectories))
            {
                string ParrentDirectories = file.FullName.GetTextAfterValue(Path.GetFullPath("wwwroot")).GetTextBeforeLastValue(@"\" + file.Name);

                if (!Directory.Exists(Path.GetFullPath(ViewPath) + ParrentDirectories))
                    Directory.CreateDirectory(Path.GetFullPath(ViewPath) + ParrentDirectories);

                File.Move(file.FullName, Path.GetFullPath(ViewPath) + ParrentDirectories + @"\" + file.Name, true);
            }
        }

        private string ImportNamespaceList()
        {
            const string NamespaceImportListPath = "code_behind/namespace_import_list.ini";
            string ReturnValue = "";

            if (!Directory.Exists("code_behind"))
                Directory.CreateDirectory("code_behind");

            if (!File.Exists(NamespaceImportListPath))
            {
                var file = File.CreateText(NamespaceImportListPath);

                file.Write("[CodeBehind namespace import list]" + Environment.NewLine);
                file.Write("namespace=System.IO" + Environment.NewLine);
                file.Write("namespace=System.Collections" + Environment.NewLine);
                file.Write("namespace=System.Collections.Generic" + Environment.NewLine);
                file.Write("namespace=System.Linq" + Environment.NewLine);
                file.Write("namespace=System.Threading" + Environment.NewLine);
                file.Write("namespace=System.Threading.Tasks");

                file.Dispose();
                file.Close();

            }

            using (StreamReader reader = new StreamReader(NamespaceImportListPath))
            {
                reader.ReadLine();

                string line;
                while ((line = reader.ReadLine()) != null)
                    ReturnValue += "using " + line.GetTextAfterValue("=") + ";" + Environment.NewLine;
            }

            if (string.IsNullOrEmpty(ReturnValue))
            {
                ReturnValue = "// Start Import Namespace List" + Environment.NewLine + ReturnValue + "// End Import Namespace List" + Environment.NewLine;
            }

            return ReturnValue;
        }

        public string GetTemplatePartName(string Text)
        {
            string ReturnValue = "";

            if (Text.Length < 1)
                return ReturnValue;


            for (int i = 0; i < Text.Length; i++)
                if (char.IsLetter(Text[i]) || char.IsNumber(Text[i]))
                    ReturnValue += Text[i];
                else
                    break;

            return ReturnValue;
        }

        public char GetCharacterAfterTemplatePartName(string Text)
        {
            if (Text.Length < 1)
                return '!';

            int i = 0;
            for (; i < Text.Length; i++)
                if (!char.IsLetter(Text[i]) && !char.IsNumber(Text[i]))
                    return Text[i];

            return Text[i - 1];
        }

        public bool PartHasTemplateValue(string Text)
        {
            if (Text.Length < 1)
                return false;

            for (int i = 0; i < Text.Length; i++)
                if (!char.IsLetter(Text[i]) && !char.IsNumber(Text[i]))
                {
                    if (Text[i] == ' ' || Text[i] == '<' || Text[i] == '\n' || Text[i] == '\t' || Text[i] == '\r')
                        return true;

                    break;
                }

            return false;
        }

        public bool HasOpenedSyntax(string InnerText, string OpenSyntaxValue, string CloseSyntaxValue)
        {
            if ((InnerText.Length < OpenSyntaxValue.Length) || (InnerText.Length < CloseSyntaxValue.Length))
                return false;


            int OpenSyntaxCount = InnerText.Split(new string[] { OpenSyntaxValue }, StringSplitOptions.None).Length - 1;
            int CloseSyntaxCount = InnerText.Split(new string[] { CloseSyntaxValue }, StringSplitOptions.None).Length - 1;

            return OpenSyntaxCount > CloseSyntaxCount;
        }
    }
}
