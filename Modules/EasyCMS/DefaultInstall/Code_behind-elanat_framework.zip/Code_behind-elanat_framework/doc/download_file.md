### Download file

You can use the Download method to download files after users request them on the view pages; the Download method has an input argument of the file path and can be accessed from all three sections: view, controller, and model.

Example:
```csharp
Download("C:\\image.png");
```
