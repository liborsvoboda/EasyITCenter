A web viewer for your local 360 image files. Based on [mistic100/Photo-Sphere-Viewer](https://github.com/mistic100/Photo-Sphere-Viewer).

:eye: Open [mitmadness.github.io/PanoramaViewer](https://mitmadness.github.io/PanoramaViewer/). :eye:

# Contributing

Pushing modifications on the master branch will directly change the viewer. The website is hosted using gh-pages.
