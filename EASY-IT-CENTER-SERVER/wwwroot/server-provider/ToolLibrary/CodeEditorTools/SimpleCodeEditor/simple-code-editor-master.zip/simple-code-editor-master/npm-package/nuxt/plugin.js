import Vue from "vue";
import CodeEditor from "simple-code-editor";
Vue.component("CodeEditor", CodeEditor);
