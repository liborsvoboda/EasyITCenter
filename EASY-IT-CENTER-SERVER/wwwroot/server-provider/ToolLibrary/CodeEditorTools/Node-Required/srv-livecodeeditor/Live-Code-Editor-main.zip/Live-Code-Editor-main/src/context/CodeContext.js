import React from 'react';

const CodeContext = React.createContext();
export default CodeContext;
