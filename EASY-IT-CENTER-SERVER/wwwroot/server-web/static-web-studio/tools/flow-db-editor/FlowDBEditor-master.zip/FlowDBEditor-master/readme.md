FlowDBEditor (visual database creator with voice recognition)
=============================================================

Lightweight graphical database schema editor. Create database in air & use in air & upload structure and data to a real database like MySQL. 
Working copy on Codepen.io (https://codepen.io/hgabor47/pen/XqezrX)
Voice recognition (voice commands) in Hungarian and English


Usage
-----
Download and run. Or USE it https://codepen.io/hgabor47/full/XqezrX/

If you use a button on FlowDBEditor that button displays a help only once.

You can create a database to the browsers' localstorage.
You can create tables
You can create fields of tables with any kind of type.
You can add records to the tables on air (stored to browsers' localstorage)
Filling the records of table takes into account the relationships (constraints links).
Write records with right click on created tables :)
Voice recognition HUN and ENG

So you can try a database without any preparation.


![Preview image](https://github.com/hgabor47/FlowDBEditor/blob/master/flowpreview1_01.jpg?raw=true "Preview")


[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=hgabor47%40gmail%2ecom&lc=AL&item_number=flowdbeditor&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)
