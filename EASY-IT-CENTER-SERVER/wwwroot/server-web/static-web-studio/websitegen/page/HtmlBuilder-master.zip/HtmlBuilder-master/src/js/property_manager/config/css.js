/**
 * propery css id
 */

 module.exports = {
    sub_category_toggle_body_div: 'hb_sub_category_toggle_body_div',

    category_body_div: 'hb_category_body_div',
    category_body_title_div: 'hb_category_body_title_div',
    category_body_title_label: 'hb_category_body_title_label',

    prop_body_div: 'hb_prop_body_div',
    prop_body_title_div: 'hb_prop_body_title_div',
    prop_body_title_label: 'hb_prop_body_title_label',
    prop_body_set_div: 'hb_prop_body_set_div',
    prop_body_set_text: 'hb_prop_body_set_text',
    prop_body_set_btn: 'hb_prop_body_set_btn',
    prop_body_set_select: 'hb_prop_body_set_select',
    prop_body_set_multi_select: 'hb_prop_body_set_multi_select',
    prop_body_set_color: 'hb_prop_body_set_color'
}