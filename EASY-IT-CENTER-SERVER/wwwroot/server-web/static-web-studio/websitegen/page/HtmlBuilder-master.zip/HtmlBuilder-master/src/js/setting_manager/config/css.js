/**
 * setting css id
 */

module.exports = {
    setting_div: 'hb_setting_div',
    setting_title_div: 'hb_setting_title_div',
    setting_content_div: 'hb_setting_content_div',

    setting_title_label: 'hb_setting_title_label'
}