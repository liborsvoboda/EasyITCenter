import { stopServer } from './server.js';

export default async () => {
  stopServer();
};
