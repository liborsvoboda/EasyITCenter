![logo](_media/icon.svg)

# docsify <small>4.13.0</small>

> A magical documentation site generator.

- Simple and lightweight
- No statically built html files
- Multiple themes

[GitHub](https://github.com/docsifyjs/docsify/)
[Getting Started](#docsify)
