demo({
      "tree": "Human deities\n Faerûnian pantheon\n  Greater deities\n  Intermediate deities\n  Lesser deities\n  Demideities\n  Quasi-deities\n  Kara-Turan pantheon\n  Maztican pantheon\n  Mulhorandi pantheon\n  Zakharan pantheon\nNonhuman racial deities\n Former Archdevil\n Dragon deities\n Drow deities\n Dwarven deities\n Elven deities\n Giant deities\n Gnome deities\n Halfling deities\n Orc deities\n Other races\nNondeity powers\n Archdevils\n Demon princes\n Paragons\n  Archon\n  Eladrin\n  Guardinal\nDead deities\n Untheric pantheon\n Others",
      "options": {
        "flipXY": 0,
        "width": 900,
        "height": 700,
        "labelLineSpacing": 13,
        "cornerRounding": 0,
        "labelPadding": 4,
        "arrowHeadSize": 5,
        "arrowsUp": 0,
        "siblingGap": 0.05,
        "idealSiblingGap": 0.3,
        "minimumCousinGap": 0.2,
        "idealCousinGap": 1.2,
        "levelsGap": 1.2,
        "minimumDepth": 6,
        "minimumBreadth": 6,
        "drawRoot": false
      },
      "styles": "text {\n  text-anchor: middle;\n  font-size: small;\n  fill: white;\n\n}\n\nrect {\n  fill: blue;\n  stroke: black;\n  opacity: 1;\n  stroke-width: 1.5;\n}\n\nline {\n  stroke: black;\n  opacity: 0.5;\n  stroke-width: 1.5;\n}\n  "
    }
);