import Vue from 'Vue'

/* eslint-disable no-new */
export default new Vue()

